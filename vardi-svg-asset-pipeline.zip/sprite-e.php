<?php
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');

if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
} else {
    session_set_cookie_params(0, '/; samesite=Strict', '', false, true);
}
session_start();

if (empty($_SESSION['vse_csrf'])) {
    $_SESSION['vse_csrf'] = bin2hex(random_bytes(32));
}

if (function_exists('libxml_disable_entity_loader')) {
    @libxml_disable_entity_loader(true);
}

function vse_has_doctype_or_entity($xml) {
    return (bool) preg_match('/<!\s*(DOCTYPE|ENTITY)/i', $xml);
}

function vse_strip_xml_prolog($s) {
    $s = preg_replace('/^\xEF\xBB\xBF/', '', (string) $s);
    $s = ltrim($s);
    return preg_replace('/^<\?xml[^>]*\?>/i', '', $s, 1);
}

function vse_lname($node) {
    $n = ($node->localName !== null && $node->localName !== '') ? $node->localName : $node->nodeName;
    return strtolower($n);
}

function vse_opt_stats($before = null, $after = null, $fallback = false) {
    static $s = ['before' => 0, 'after' => 0, 'fallbacks' => 0];
    if ($before !== null) {
        $s['before'] += $before;
        $s['after'] += $after;
        if ($fallback) {
            $s['fallbacks']++;
        }
    }
    return $s;
}

function vse_last_meta($m = null) {
    static $last = [];
    if ($m !== null) {
        $last = $m;
    }
    return $last;
}

function vse_store_icon($id, $xml) {
    $_SESSION['vse_icons'][$id] = $xml;
    $_SESSION['vse_meta'][$id] = vse_last_meta();
}

function vse_strip_xmlns($xml) {
    return preg_replace('/\s+xmlns(:[a-zA-Z0-9]+)?="[^"]*"/', '', $xml);
}

function vse_fmt_num($n, $precision) {
    $r = round($n, $precision);
    if ($r == 0) {
        return '0';
    }
    $s = number_format($r, $precision, '.', '');
    if (strpos($s, '.') !== false) {
        $s = rtrim(rtrim($s, '0'), '.');
    }
    if (strpos($s, '0.') === 0) {
        $s = substr($s, 1);
    } elseif (strpos($s, '-0.') === 0) {
        $s = '-' . substr($s, 2);
    }
    return $s;
}

function vse_round_numbers_in($s, $precision) {
    return preg_replace_callback(
        '/[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/',
        function ($m) use ($precision) {
            return vse_fmt_num((float) $m[0], $precision);
        },
        $s
    );
}

function vse_round_path_data($d, $precision) {
    $known = ['m', 'l', 'h', 'v', 'c', 's', 'q', 't', 'a', 'z'];
    $re = '/\G[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/';
    $len = strlen($d);
    $i = 0;
    $out = '';
    $cmd = '';
    $argIdx = 0;
    $lastNum = false;

    while ($i < $len) {
        $ch = $d[$i];
        if ($ch === ' ' || $ch === ',' || $ch === "\t" || $ch === "\n" || $ch === "\r") {
            $i++;
            continue;
        }
        if (ctype_alpha($ch)) {
            if (!in_array(strtolower($ch), $known, true)) {
                return null;
            }
            $cmd = $ch;
            $argIdx = 0;
            $lastNum = false;
            $out .= $ch;
            $i++;
            continue;
        }
        if ($cmd === '' || strtolower($cmd) === 'z') {
            return null;
        }
        if (strtolower($cmd) === 'a' && ($argIdx % 7 === 3 || $argIdx % 7 === 4)) {
            if ($ch !== '0' && $ch !== '1') {
                return null;
            }
            $tok = $ch;
            $i++;
        } else {
            if (!preg_match($re, $d, $m, 0, $i)) {
                return null;
            }
            $tok = vse_fmt_num((float) $m[0], $precision);
            $i += strlen($m[0]);
        }
        if ($lastNum && $tok[0] !== '-') {
            $out .= ' ';
        }
        $out .= $tok;
        $lastNum = true;
        $argIdx++;
    }
    return $out;
}

function vse_attr_blob(DOMElement $symbol, DOMXPath $xpath) {
    $parts = [];
    foreach ($xpath->query('descendant-or-self::*/@*', $symbol) as $a) {
        if ($a->nodeName === 'id') {
            continue;
        }
        $parts[] = $a->nodeValue;
    }
    return implode("\n", $parts);
}

function vse_is_blank_element(DOMElement $el) {
    foreach ($el->childNodes as $c) {
        if ($c->nodeType === XML_ELEMENT_NODE) {
            return false;
        }
        if (($c->nodeType === XML_TEXT_NODE || $c->nodeType === XML_CDATA_SECTION_NODE) && trim($c->nodeValue) !== '') {
            return false;
        }
    }
    return true;
}

function vse_try_flatten_group(DOMElement $g) {
    $parent = $g->parentNode;
    if (!$parent) {
        return false;
    }
    $elChildren = [];
    foreach ($g->childNodes as $c) {
        if ($c->nodeType === XML_ELEMENT_NODE) {
            $elChildren[] = $c;
        } elseif (($c->nodeType === XML_TEXT_NODE || $c->nodeType === XML_CDATA_SECTION_NODE) && trim($c->nodeValue) !== '') {
            return false;
        }
    }

    $attrs = [];
    foreach ($g->attributes as $a) {
        $attrs[] = $a;
    }

    if (count($attrs) === 0) {
        while ($g->firstChild) {
            $parent->insertBefore($g->firstChild, $g);
        }
        $parent->removeChild($g);
        return true;
    }

    if (count($elChildren) !== 1) {
        return false;
    }
    $child = $elChildren[0];
    if (!in_array(vse_lname($child), ['path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'g', 'use'], true)) {
        return false;
    }

    $blockers = ['id', 'clip-path', 'mask', 'filter', 'style', 'class'];
    $conflicts = ['transform', 'opacity', 'display'];
    foreach ($attrs as $a) {
        if ($a->prefix !== '' && $a->prefix !== null) {
            return false;
        }
        if (in_array($a->nodeName, $blockers, true)) {
            return false;
        }
        if (in_array($a->nodeName, $conflicts, true) && $child->hasAttribute($a->nodeName)) {
            return false;
        }
    }

    foreach ($attrs as $a) {
        if (!$child->hasAttribute($a->nodeName)) {
            $child->setAttribute($a->nodeName, $a->nodeValue);
        }
    }
    $parent->replaceChild($child, $g);
    return true;
}

function vse_optimize_symbol(DOMElement $symbol, $precision = 3) {
    $svgNs = 'http://www.w3.org/2000/svg';
    $xpath = new DOMXPath($symbol->ownerDocument);
    $animNames = ['animate', 'animatetransform', 'animatemotion', 'set', 'animatecolor', 'discard'];
    $shapes = ['path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon'];

    $risky = false;
    foreach ($xpath->query('descendant-or-self::*', $symbol) as $el) {
        $n = vse_lname($el);
        if ($n === 'use' || in_array($n, $animNames, true)) {
            $risky = true;
            break;
        }
    }

    $drop = [];
    foreach ($xpath->query('.//*', $symbol) as $el) {
        $ns = $el->namespaceURI;
        if (($ns !== null && $ns !== '' && $ns !== $svgNs) || vse_lname($el) === 'metadata') {
            $drop[] = $el;
        }
    }
    foreach ($drop as $el) {
        if ($el->parentNode) {
            $el->parentNode->removeChild($el);
        }
    }
    foreach ($xpath->query('descendant-or-self::*', $symbol) as $el) {
        $rm = [];
        foreach ($el->attributes as $a) {
            $p = $a->prefix;
            $foreign = ($p !== '' && $p !== null && $p !== 'xlink' && $p !== 'xml' && $p !== 'xmlns');
            if ($foreign || $a->nodeName === 'data-name') {
                $rm[] = $a;
            }
        }
        foreach ($rm as $a) {
            $el->removeAttributeNode($a);
        }
    }

    if (!$risky) {
        $inherited = ['fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit',
                      'stroke-opacity', 'fill-opacity', 'fill-rule', 'clip-rule', 'stroke-dasharray', 'stroke-dashoffset'];
        foreach ($xpath->query('.//*', $symbol) as $el) {
            $n = vse_lname($el);
            if ($n !== 'g' && !in_array($n, $shapes, true)) {
                continue;
            }
            if ($el->getAttribute('opacity') === '1') {
                $el->removeAttribute('opacity');
            }
            foreach ($inherited as $attr) {
                if (!$el->hasAttribute($attr)) {
                    continue;
                }
                $val = trim($el->getAttribute($attr));
                $p = $el->parentNode;
                while ($p instanceof DOMElement) {
                    if ($p->hasAttribute($attr)) {
                        if (trim($p->getAttribute($attr)) === $val) {
                            $el->removeAttribute($attr);
                        }
                        break;
                    }
                    if ($p === $symbol) {
                        break;
                    }
                    $p = $p->parentNode;
                }
            }
        }
    }

    if ($precision !== null) {
        $plain = '/^\s*[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?\s*$/';
        $geom = ['x', 'y', 'width', 'height', 'cx', 'cy', 'r', 'rx', 'ry', 'x1', 'y1', 'x2', 'y2'];
        foreach ($xpath->query('.//*', $symbol) as $el) {
            $n = vse_lname($el);
            if (!in_array($n, $shapes, true)) {
                continue;
            }
            if ($n === 'path' && $el->hasAttribute('d')) {
                $new = vse_round_path_data($el->getAttribute('d'), $precision);
                if ($new !== null && $new !== '') {
                    $el->setAttribute('d', $new);
                }
            }
            if (($n === 'polyline' || $n === 'polygon') && $el->hasAttribute('points')) {
                $el->setAttribute('points', trim(vse_round_numbers_in($el->getAttribute('points'), $precision)));
            }
            foreach ($geom as $a) {
                if ($el->hasAttribute($a) && preg_match($plain, $el->getAttribute($a))) {
                    $el->setAttribute($a, vse_fmt_num((float) $el->getAttribute($a), $precision));
                }
            }
        }
    }

    if (!$risky) {
        for ($pass = 0; $pass < 10; $pass++) {
            $changed = false;
            foreach ($xpath->query('.//*[local-name()="g"]', $symbol) as $g) {
                if ($g->parentNode && vse_try_flatten_group($g)) {
                    $changed = true;
                }
            }
            if (!$changed) {
                break;
            }
        }
    }

    $all = $xpath->query('.//*', $symbol);
    for ($i = $all->length - 1; $i >= 0; $i--) {
        $el = $all->item($i);
        if (!$el->parentNode || !in_array(vse_lname($el), ['g', 'defs', 'title', 'desc'], true)) {
            continue;
        }
        if (vse_is_blank_element($el)) {
            $el->parentNode->removeChild($el);
        }
    }

    $refable = ['lineargradient', 'radialgradient', 'clippath', 'mask', 'filter', 'marker', 'pattern'];
    for ($pass = 0; $pass < 5; $pass++) {
        $blob = vse_attr_blob($symbol, $xpath);
        $removed = false;
        foreach ($xpath->query('.//*', $symbol) as $el) {
            if (!$el->parentNode) {
                continue;
            }
            $n = vse_lname($el);
            $inDefs = vse_lname($el->parentNode) === 'defs';
            if (!in_array($n, $refable, true) && !($inDefs && !in_array($n, $animNames, true))) {
                continue;
            }
            $id = $el->getAttribute('id');
            if ($id === '' || strpos($blob, $id) === false) {
                $el->parentNode->removeChild($el);
                $removed = true;
            }
        }
        if (!$removed) {
            break;
        }
    }
    $all = $xpath->query('.//*[local-name()="defs"]', $symbol);
    for ($i = $all->length - 1; $i >= 0; $i--) {
        $el = $all->item($i);
        if ($el->parentNode && vse_is_blank_element($el)) {
            $el->parentNode->removeChild($el);
        }
    }

    $blob = vse_attr_blob($symbol, $xpath);
    foreach ($xpath->query('.//*[@id]', $symbol) as $el) {
        $id = $el->getAttribute('id');
        if ($id === '' || strpos($blob, $id) === false) {
            $el->removeAttribute('id');
        }
    }
}

function vse_clean_dom(DOMDocument $dom) {
    $forbidden = ['script', 'iframe', 'object', 'embed', 'link', 'style', 'foreignobject',
                  'a', 'handler', 'listener', 'image', 'discard'];
    $upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lower = 'abcdefghijklmnopqrstuvwxyz';
    $xpath = new DOMXPath($dom);
    foreach ($forbidden as $tag) {
        $nodes = $xpath->query("//*[translate(local-name(),'$upper','$lower')='" . $tag . "']");
        for ($i = $nodes->length - 1; $i >= 0; $i--) {
            $node = $nodes->item($i);
            if ($node->parentNode) {
                $node->parentNode->removeChild($node);
            }
        }
    }

    $comments = $xpath->query('//comment()');
    for ($i = $comments->length - 1; $i >= 0; $i--) {
        $node = $comments->item($i);
        if ($node->parentNode) {
            $node->parentNode->removeChild($node);
        }
    }

    $eventAttrs = $xpath->query("//@*[starts-with(translate(name(),'$upper','$lower'), 'on')]");
    foreach ($eventAttrs as $attr) {
        $attr->ownerElement->removeAttribute($attr->nodeName);
    }

    $styleAttrs = $xpath->query("//@*[translate(name(),'$upper','$lower')='style']");
    foreach ($styleAttrs as $attr) {
        $attr->ownerElement->removeAttribute($attr->nodeName);
    }

    $hrefAttrs = $xpath->query("//@*[translate(local-name(),'$upper','$lower')='href']");
    foreach ($hrefAttrs as $attr) {
        $value = trim($attr->nodeValue);
        if ($value === '' || substr($value, 0, 1) !== '#') {
            $attr->ownerElement->removeAttribute($attr->nodeName);
        }
    }

    $allAttrs = $xpath->query('//@*');
    $toStrip = [];
    foreach ($allAttrs as $attr) {
        if (stripos($attr->nodeValue, 'url') === false) {
            continue;
        }
        if (preg_match_all('/url\s*\(\s*([\'"]?)\s*([^)\'"]*)/i', $attr->nodeValue, $m)) {
            foreach ($m[2] as $target) {
                if (substr(trim($target), 0, 1) !== '#') {
                    $toStrip[] = $attr;
                    break;
                }
            }
        }
    }
    foreach ($toStrip as $attr) {
        if ($attr->ownerElement) {
            $attr->ownerElement->removeAttribute($attr->nodeName);
        }
    }

    $allowedAnim = ['opacity', 'transform', 'r', 'rx', 'ry', 'cx', 'cy', 'x', 'y', 'x1', 'x2', 'y1', 'y2',
        'width', 'height', 'd', 'points', 'fill', 'stroke', 'fill-opacity', 'stroke-opacity',
        'stroke-width', 'stroke-dasharray', 'stroke-dashoffset', 'stop-color', 'stop-opacity',
        'offset', 'display', 'visibility', 'stdDeviation', 'dx', 'dy', 'flood-color',
        'flood-opacity', 'gradientTransform', 'patternTransform', 'fx', 'fy'];
    $allowedAnimLc = array_map('strtolower', $allowedAnim);
    $anims = $xpath->query("//*[translate(local-name(),'$upper','$lower')='animate' or translate(local-name(),'$upper','$lower')='set' or translate(local-name(),'$upper','$lower')='animatetransform' or translate(local-name(),'$upper','$lower')='animatemotion' or translate(local-name(),'$upper','$lower')='animatecolor']");
    for ($i = $anims->length - 1; $i >= 0; $i--) {
        $node = $anims->item($i);
        $kind = strtolower($node->localName);
        $drop = false;
        if ($kind !== 'animatemotion') {
            $name = strtolower(trim($node->getAttribute('attributeName')));
            if (strpos($name, ':') !== false) {
                $name = substr($name, strrpos($name, ':') + 1);
            }
            if ($name === '' || !in_array($name, $allowedAnimLc, true)) {
                $drop = true;
            }
            if ($kind === 'animatetransform' && $name !== 'transform') {
                $drop = true;
            }
        }
        foreach (['to', 'from', 'by', 'values'] as $vAttr) {
            if ($node->hasAttribute($vAttr) && preg_match('/(javascript|data|vbscript)\s*:/i', $node->getAttribute($vAttr))) {
                $drop = true;
            }
        }
        if ($drop && $node->parentNode) {
            $node->parentNode->removeChild($node);
        }
    }
}

function vse_resolve_viewbox(DOMElement $source) {
    if ($source->hasAttribute('viewBox') && trim($source->getAttribute('viewBox')) !== '') {
        return trim($source->getAttribute('viewBox'));
    }
    $w = $source->hasAttribute('width') ? (float)$source->getAttribute('width') : 0;
    $h = $source->hasAttribute('height') ? (float)$source->getAttribute('height') : 0;
    if ($w > 0 && $h > 0) {
        return '0 0 ' . $w . ' ' . $h;
    }
    return '0 0 24 24';
}

function vse_animation_info(DOMElement $root) {
    $upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lower = 'abcdefghijklmnopqrstuvwxyz';
    $cond = [];
    foreach (['animate', 'animatetransform', 'animatemotion', 'animatecolor', 'set', 'discard'] as $tag) {
        $cond[] = "translate(local-name(),'$upper','$lower')='$tag'";
    }
    $xpath = new DOMXPath($root->ownerDocument);
    $nodes = $xpath->query('descendant-or-self::*[' . implode(' or ', $cond) . ']', $root);
    $attrs = [];
    foreach ($nodes as $node) {
        $kind = strtolower($node->localName);
        if ($kind === 'animatetransform') {
            $attrs['transform'] = true;
            continue;
        }
        if ($kind === 'animatemotion' || $kind === 'discard') {
            continue;
        }
        $name = strtolower(trim($node->getAttribute('attributeName')));
        if (strpos($name, ':') !== false) {
            $name = substr($name, strrpos($name, ':') + 1);
        }
        if ($name !== '') {
            $attrs[$name] = true;
        }
    }
    return ['animated' => $nodes->length > 0, 'count' => $nodes->length, 'attrs' => $attrs];
}

function vse_symbol_facts($xml) {
    $wrapped = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">' . $xml . '</svg>';
    $prev = libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $ok = $dom->loadXML($wrapped, LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($prev);
    if (!$ok || !$dom->documentElement) {
        return null;
    }
    $xp = new DOMXPath($dom);

    $ids = [];
    $dups = [];
    foreach ($xp->query('//*[@id]') as $el) {
        $id = $el->getAttribute('id');
        if (isset($ids[$id])) {
            $dups[$id] = true;
        }
        $ids[$id] = true;
    }

    $smil = '/^\s*(.+?)\.(?:begin|end|repeat|click|dblclick|mousedown|mouseup|mouseover|mouseout|mousemove|focusin|focusout|activate|load)\b/i';
    $refs = [];
    foreach ($xp->query('//@*') as $a) {
        $name = strtolower($a->nodeName);
        $v = (string) $a->nodeValue;
        if (stripos($v, 'url') !== false && preg_match_all('/url\(\s*[\'"]?\s*#([^)\'"\s]+)/i', $v, $m)) {
            foreach ($m[1] as $r) {
                $refs[$r] = true;
            }
        }
        if (($name === 'href' || $name === 'xlink:href') && substr(trim($v), 0, 1) === '#') {
            $refs[substr(trim($v), 1)] = true;
        }
        if ($name === 'aria-labelledby' || $name === 'aria-describedby') {
            foreach (preg_split('/\s+/', trim($v)) as $r) {
                if ($r !== '') {
                    $refs[$r] = true;
                }
            }
        }
        if ($name === 'begin' || $name === 'end') {
            foreach (explode(';', $v) as $part) {
                if (preg_match($smil, $part, $m)) {
                    $refs[$m[1]] = true;
                }
            }
        }
    }
    $broken = [];
    foreach ($refs as $r => $unused) {
        if (!isset($ids[$r])) {
            $broken[$r] = true;
        }
    }

    $shapeCond = "local-name()='path' or local-name()='rect' or local-name()='circle' or local-name()='ellipse' or local-name()='line' or local-name()='polyline' or local-name()='polygon' or local-name()='text' or local-name()='use' or local-name()='image'";
    $notInDefs = "not(ancestor::*[local-name()='defs' or local-name()='clipPath' or local-name()='mask' or local-name()='pattern' or local-name()='marker'])";
    $shapes = $xp->query("//*[($shapeCond) and $notInDefs]")->length;
    $pathsD = $xp->query("//*[local-name()='path' and string-length(normalize-space(@d)) > 0]")->length;

    $viewBoxOk = false;
    $symbol = $dom->getElementsByTagName('symbol')->item(0);
    if ($symbol) {
        $parts = preg_split('/[\s,]+/', trim($symbol->getAttribute('viewBox')));
        $viewBoxOk = count($parts) === 4 && is_numeric($parts[0]) && is_numeric($parts[1])
            && is_numeric($parts[2]) && is_numeric($parts[3]) && $parts[2] > 0 && $parts[3] > 0;
    }

    $anim = vse_animation_info($dom->documentElement);

    return [
        'dups' => $dups,
        'broken' => $broken,
        'animCount' => $anim['count'],
        'animAttrs' => array_keys($anim['attrs']),
        'shapes' => $shapes,
        'pathsD' => $pathsD,
        'viewBoxOk' => $viewBoxOk,
    ];
}

function vse_validate_optimized($plainXml, $optXml) {
    $b = vse_symbol_facts($optXml);
    if ($b === null) {
        return 'XML invalido apos otimizar';
    }
    $a = vse_symbol_facts($plainXml);
    if ($a === null) {
        return null;
    }
    foreach ($b['broken'] as $id => $unused) {
        if (!isset($a['broken'][$id])) {
            return 'referencia quebrada: ' . $id;
        }
    }
    foreach ($b['dups'] as $id => $unused) {
        if (!isset($a['dups'][$id])) {
            return 'id duplicado: ' . $id;
        }
    }
    $ka = $a['animAttrs'];
    $kb = $b['animAttrs'];
    sort($ka);
    sort($kb);
    if ($a['animCount'] !== $b['animCount'] || $ka !== $kb) {
        return 'animacao alterada';
    }
    if ($a['shapes'] !== $b['shapes'] || $a['pathsD'] !== $b['pathsD']) {
        return 'geometria alterada';
    }
    if ($a['viewBoxOk'] && !$b['viewBoxOk']) {
        return 'viewBox invalido';
    }
    return null;
}

function vse_normalize_colors(DOMElement $source) {
    $xpath = new DOMXPath($source->ownerDocument);

    $upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lower = 'abcdefghijklmnopqrstuvwxyz';
    $complexTags = ['lineargradient', 'radialgradient', 'pattern', 'filter', 'mask'];
    $cond = [];
    foreach ($complexTags as $tag) {
        $cond[] = "translate(local-name(),'$upper','$lower')='$tag'";
    }
    if ($xpath->query('descendant-or-self::*[' . implode(' or ', $cond) . ']', $source)->length > 0
        || $xpath->query('descendant-or-self::*[@stop-color]', $source)->length > 0) {
        return ['usesStroke' => false, 'multicolor' => true];
    }
    $animInfo = vse_animation_info($source);
    foreach (['fill', 'stroke', 'stop-color', 'flood-color', 'lighting-color', 'color'] as $colorAttr) {
        if (isset($animInfo['attrs'][$colorAttr])) {
            return ['usesStroke' => false, 'multicolor' => true];
        }
    }
    foreach (['fill', 'stroke'] as $attrName) {
        foreach ($xpath->query('descendant-or-self::*[@' . $attrName . ']', $source) as $node) {
            if (stripos($node->getAttribute($attrName), 'url(') !== false) {
                return ['usesStroke' => false, 'multicolor' => true];
            }
        }
    }

    $colors = [];
    foreach (['fill', 'stroke'] as $attrName) {
        $nodes = $xpath->query('descendant-or-self::*[@' . $attrName . ']', $source);
        foreach ($nodes as $node) {
            $value = strtolower(trim($node->getAttribute($attrName)));
            if ($value !== '' && $value !== 'none') {
                $colors[$value] = true;
            }
        }
    }

    if (count($colors) > 1) {
        return ['usesStroke' => false, 'multicolor' => true];
    }

    $usesStroke = false;
    foreach (['fill', 'stroke'] as $attrName) {
        $nodes = $xpath->query('descendant-or-self::*[@' . $attrName . ']', $source);
        foreach ($nodes as $node) {
            $value = strtolower(trim($node->getAttribute($attrName)));
            if ($value !== 'none') {
                if ($attrName === 'stroke') {
                    $usesStroke = true;
                }
                $node->removeAttribute($attrName);
            }
        }
    }

    return ['usesStroke' => $usesStroke, 'multicolor' => false];
}

function vse_id_from_filename($name) {
    $base = basename(str_replace('\\', '/', (string) $name));
    $base = preg_replace('/\.svg$/i', '', $base);
    $base = preg_replace('/[^A-Za-z0-9_\-:.]+/', '-', $base);
    return vse_sanitize_id(trim($base, '-.'));
}

function vse_sanitize_id($id) {
    $id = trim((string)$id);
    if ($id === '' || strlen($id) > 128) {
        return '';
    }
    if (!preg_match('/^[A-Za-z0-9_\-:.]+$/', $id)) {
        return '';
    }
    return $id;
}

function vse_collect_refs(DOMElement $source) {
    $xpath = new DOMXPath($source->ownerDocument);
    $refs = [];
    foreach ($xpath->query('descendant-or-self::*/@*', $source) as $attr) {
        $v = $attr->nodeValue;
        if (strpos($v, '#') === false) {
            continue;
        }
        if (preg_match_all('/url\s*\(\s*[\'"]?\s*#([^)\'"\s]+)/i', $v, $m)) {
            foreach ($m[1] as $r) {
                $refs[$r] = true;
            }
        }
        if (strtolower($attr->localName) === 'href' && substr(trim($v), 0, 1) === '#') {
            $refs[substr(trim($v), 1)] = true;
        }
    }
    return array_keys($refs);
}

function vse_inline_external_refs(DOMElement $source) {
    $doc = $source->ownerDocument;
    $xpath = new DOMXPath($doc);
    $own = [];
    foreach ($xpath->query('descendant-or-self::*[@id]', $source) as $n) {
        $own[$n->getAttribute('id')] = true;
    }
    $global = [];
    foreach ($xpath->query('//*[@id]') as $n) {
        $gid = $n->getAttribute('id');
        if (!isset($global[$gid])) {
            $global[$gid] = $n;
        }
    }
    $defs = null;
    $cloned = 0;
    for ($pass = 0; $pass < 5; $pass++) {
        $added = false;
        foreach (vse_collect_refs($source) as $ref) {
            if (isset($own[$ref]) || !isset($global[$ref]) || $cloned >= 60) {
                continue;
            }
            $node = $global[$ref];
            if (strtolower($node->localName) === 'symbol' || strtolower($node->localName) === 'svg') {
                continue;
            }
            if ($defs === null) {
                $defs = $doc->createElementNS('http://www.w3.org/2000/svg', 'defs');
                $source->insertBefore($defs, $source->firstChild);
            }
            $clone = $defs->appendChild($node->cloneNode(true));
            $own[$ref] = true;
            foreach ($xpath->query('descendant-or-self::*[@id]', $clone) as $cn) {
                $own[$cn->getAttribute('id')] = true;
            }
            $cloned++;
            $added = true;
        }
        if (!$added) {
            break;
        }
    }
}

function vse_namespace_ids(DOMElement $source, $symbolId) {
    $xpath = new DOMXPath($source->ownerDocument);
    $map = [];
    $taken = [];
    foreach ($xpath->query('descendant::*[@id]', $source) as $n) {
        $old = $n->getAttribute('id');
        if ($old === '' || isset($map[$old])) {
            continue;
        }
        $base = strpos($old, $symbolId . '--') === 0
            ? $old
            : $symbolId . '--' . preg_replace('/[^A-Za-z0-9_\-.:]/', '_', $old);
        $new = $base;
        $k = 2;
        while (isset($taken[$new])) {
            $new = $base . '-' . $k++;
        }
        $taken[$new] = true;
        $map[$old] = $new;
    }
    if (!$map) {
        return;
    }
    uksort($map, function ($a, $b) {
        return strlen($b) - strlen($a);
    });

    foreach ($xpath->query('descendant-or-self::*/@*', $source) as $attr) {
        $name = $attr->nodeName;
        $v = $attr->nodeValue;
        $lname = strtolower($attr->localName);
        if ($lname === 'id') {
            if (!$attr->ownerElement->isSameNode($source) && isset($map[$v])) {
                $attr->value = $map[$v];
            }
            continue;
        }
        $nv = $v;
        if (strpos($nv, '#') !== false) {
            $nv = preg_replace_callback('/url\s*\(\s*([\'"]?)\s*#([^)\'"\s]+)\s*\1\s*\)/i', function ($m) use ($map) {
                return isset($map[$m[2]]) ? 'url(#' . $map[$m[2]] . ')' : $m[0];
            }, $nv);
            if ($lname === 'href' && substr(trim($nv), 0, 1) === '#') {
                $target = substr(trim($nv), 1);
                if (isset($map[$target])) {
                    $nv = '#' . $map[$target];
                }
            }
        }
        if (($lname === 'begin' || $lname === 'end') && strpos($nv, '.') !== false) {
            foreach ($map as $old => $new) {
                $nv = preg_replace('/(?<![\w.:\-])' . preg_quote($old, '/') . '(?=\.[A-Za-z])/', $new, $nv);
            }
        }
        if (($lname === 'aria-labelledby' || $lname === 'aria-describedby') && $nv !== '') {
            $parts = preg_split('/\s+/', trim($nv));
            foreach ($parts as $pi => $part) {
                if (isset($map[$part])) {
                    $parts[$pi] = $map[$part];
                }
            }
            $nv = implode(' ', $parts);
        }
        if ($nv !== $v) {
            $attr->value = $nv;
        }
    }
}

function vse_build_symbol(DOMElement $source, $id, $opt = null, $rawBytes = null) {
    vse_inline_external_refs($source);
    vse_namespace_ids($source, $id);
    $rootFillIsNone = strtolower(trim($source->getAttribute('fill'))) === 'none';
    $colorInfo = vse_normalize_colors($source);

    $outDom = new DOMDocument('1.0', 'UTF-8');
    $symbol = $outDom->createElementNS('http://www.w3.org/2000/svg', 'symbol');
    $symbol->setAttribute('id', $id);
    $symbol->setAttribute('viewBox', vse_resolve_viewbox($source));

    if ($colorInfo['multicolor']) {
        $symbol->setAttribute('fill', $source->hasAttribute('fill') ? $source->getAttribute('fill') : '#000');
        $symbol->setAttribute('stroke', $source->hasAttribute('stroke') ? $source->getAttribute('stroke') : 'none');
        if (!$source->hasAttribute('stroke-width')) {
            $symbol->setAttribute('stroke-width', '1');
        }
    } else {
        $symbol->setAttribute('fill', $rootFillIsNone ? 'none' : 'currentColor');
        $symbol->setAttribute('stroke', $colorInfo['usesStroke'] ? 'currentColor' : 'none');
        if ($colorInfo['usesStroke'] && !$source->hasAttribute('stroke-width')) {
            $symbol->setAttribute('stroke-width', '1.5');
        }
    }

    $allowedAttrs = ['stroke-width', 'stroke-linecap', 'stroke-linejoin', 'clip-rule', 'fill-rule'];
    foreach ($allowedAttrs as $attr) {
        if ($source->hasAttribute($attr)) {
            $symbol->setAttribute($attr, $source->getAttribute($attr));
        }
    }

    foreach ($source->childNodes as $child) {
        if ($child->nodeType === XML_ELEMENT_NODE || $child->nodeType === XML_TEXT_NODE) {
            $imported = $outDom->importNode($child, true);
            $symbol->appendChild($imported);
        }
    }

    $outDom->appendChild($symbol);

    $info = vse_animation_info($symbol);
    $plainXml = vse_strip_xmlns($outDom->saveXML($symbol));
    $xml = $plainXml;
    $status = 'off';

    if (is_array($opt)) {
        vse_optimize_symbol($symbol, $opt['precision']);
        $optXml = vse_strip_xmlns($outDom->saveXML($symbol));
        if (vse_validate_optimized($plainXml, $optXml) === null) {
            $xml = $optXml;
            $status = 'optimized';
        } else {
            $status = 'fallback';
        }
        vse_opt_stats($rawBytes !== null ? (int) $rawBytes : strlen($plainXml), strlen($xml), $status === 'fallback');
    }

    vse_last_meta([
        'raw' => $rawBytes !== null ? (int) $rawBytes : strlen($plainXml),
        'size' => strlen($xml),
        'status' => $status,
        'animated' => $info['animated'],
    ]);

    return $xml;
}

function vse_session_bytes() {
    $total = 0;
    foreach (($_SESSION['vse_icons'] ?? []) as $svg) {
        $total += strlen($svg);
    }
    return $total;
}

function vse_fits_in_session($id, $symbol) {
    $old = isset($_SESSION['vse_icons'][$id]) ? strlen($_SESSION['vse_icons'][$id]) : 0;
    return vse_session_bytes() - $old + strlen($symbol) <= VSE_MAX_SESSION_BYTES;
}

function vse_unique_id($id) {
    if (!isset($_SESSION['vse_icons'][$id])) {
        return $id;
    }
    $n = 2;
    while (isset($_SESSION['vse_icons'][$id . '--' . $n])) {
        $n++;
    }
    return $id . '--' . $n;
}

define('VSE_MAX_INPUT_BYTES', 3 * 1024 * 1024);
define('VSE_MAX_ICONS', 2000);
define('VSE_MAX_SESSION_BYTES', 32 * 1024 * 1024);

$rawInput = file_get_contents('php://input');
if (!empty($rawInput)) {
    if (strlen($rawInput) > VSE_MAX_INPUT_BYTES) {
        ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 'error', 'message' => 'Requisicao excede o limite de tamanho permitido.']);
        exit;
    }
    $req = json_decode($rawInput, true);

    if (is_array($req)) {
        if (isset($req['action'])) {
            $response = ['status' => 'success'];
            $csrfValid = isset($req['csrf']) && hash_equals($_SESSION['vse_csrf'], (string) $req['csrf']);

            if ($csrfValid === false) {
                $response = ['status' => 'error', 'message' => 'CSRF Token invalido.'];
            } else {
                if (!isset($_SESSION['vse_icons'])) {
                    $_SESSION['vse_icons'] = [];
                }

                $action = $req['action'];

                $opt = null;
                if (!array_key_exists('optimize', $req) || $req['optimize']) {
                    $prec = isset($req['precision']) ? (int) $req['precision'] : 3;
                    $opt = ['precision' => ($prec < 0) ? null : min(6, $prec)];
                }

                if ($action === 'add') {
                    $id = vse_sanitize_id($req['id'] ?? '');
                    $svg = trim((string)($req['svg'] ?? ''));

                    if ($id === '') {
                        $response['status'] = 'error';
                        $response['message'] = 'ID invalido. Use apenas letras, numeros, "-", "_", ":" ou "." (max 128 caracteres).';
                    } elseif ($svg === '') {
                        $response['status'] = 'error';
                        $response['message'] = 'SVG e obrigatorio.';
                    } elseif (vse_has_doctype_or_entity($svg)) {
                        $response['status'] = 'error';
                        $response['message'] = 'DOCTYPE/ENTITY nao e permitido por seguranca.';
                    } elseif (count($_SESSION['vse_icons']) >= VSE_MAX_ICONS) {
                        $response['status'] = 'error';
                        $response['message'] = 'Limite de ' . VSE_MAX_ICONS . ' icones por sessao atingido.';
                    } else {
                        $dom = new DOMDocument();
                        libxml_use_internal_errors(true);
                        $wrapped = '<?xml version="1.0" encoding="UTF-8"?><wrapper>' . vse_strip_xml_prolog($svg) . '</wrapper>';

                        $loaded = $dom->loadXML($wrapped, LIBXML_NONET);
                        libxml_clear_errors();

                        if ($loaded) {
                            vse_clean_dom($dom);

                            $source = null;
                            $svgs = $dom->getElementsByTagName('svg');
                            $symbols = $dom->getElementsByTagName('symbol');

                            if ($svgs->length > 0) {
                                $source = $svgs->item(0);
                            } elseif ($symbols->length > 0) {
                                $source = $symbols->item(0);
                            }

                            if ($source) {
                                $finalId = vse_unique_id($id);
                                $symbolXml = vse_build_symbol($source, $finalId, $opt, strlen($svg));
                                if (!vse_fits_in_session($finalId, $symbolXml)) {
                                    $response['status'] = 'error';
                                    $response['message'] = 'Limite de ' . (VSE_MAX_SESSION_BYTES / 1048576) . ' MB de SVG por sessao atingido.';
                                } else {
                                    vse_store_icon($finalId, $symbolXml);
                                    if ($finalId !== $id) {
                                        $response['message'] = 'Já existia um ícone "' . $id . '" - este foi salvo como "' . $finalId . '".';
                                    }
                                }
                            } else {
                                $response['status'] = 'error';
                                $response['message'] = 'Nenhuma tag valida encontrada.';
                            }
                        } else {
                            $response['status'] = 'error';
                            $response['message'] = 'Codigo SVG malformado.';
                        }
                    }
                } elseif ($action === 'import') {
                    $svgContent = trim((string)($req['svg'] ?? ''));

                    if ($svgContent !== '' && vse_has_doctype_or_entity($svgContent)) {
                        $response['status'] = 'error';
                        $response['message'] = 'DOCTYPE/ENTITY nao e permitido por seguranca.';
                    } elseif ($svgContent !== '') {
                        $dom = new DOMDocument();
                        libxml_use_internal_errors(true);
                        $wrapped = '<?xml version="1.0" encoding="UTF-8"?><wrapper>' . vse_strip_xml_prolog($svgContent) . '</wrapper>';

                        $loaded = $dom->loadXML($wrapped, LIBXML_NONET);
                        libxml_clear_errors();

                        if ($loaded) {
                            foreach ($dom->getElementsByTagName('symbol') as $rawNode) {
                                $rawNode->setAttribute('data-vse-raw', (string) strlen(vse_strip_xmlns($dom->saveXML($rawNode))));
                            }
                            $rawSvg = $dom->getElementsByTagName('svg')->item(0);
                            if ($rawSvg) {
                                $rawSvg->setAttribute('data-vse-raw', (string) strlen(vse_strip_xmlns($dom->saveXML($rawSvg))));
                            }
                            vse_clean_dom($dom);

                            $sources = [];
                            foreach ($dom->getElementsByTagName('symbol') as $symbolNode) {
                                $sources[] = [$symbolNode, vse_sanitize_id($symbolNode->getAttribute('id'))];
                            }
                            if (count($sources) === 0) {
                                $svgNode = $dom->getElementsByTagName('svg')->item(0);
                                if ($svgNode) {
                                    $fileId = vse_id_from_filename($req['name'] ?? '');
                                    $sources[] = [$svgNode, $fileId !== '' ? $fileId : vse_sanitize_id($svgNode->getAttribute('id'))];
                                }
                            }
                            $total = count($sources);
                            if ($total === 0) {
                                $response['status'] = 'error';
                                $response['message'] = 'Nenhum <symbol> ou <svg> encontrado no arquivo.';
                            }
                            $skipped = 0;
                            $renamed = 0;
                            $capped = 0;
                            $bytesCapped = false;
                            for ($i = 0; $i < $total; $i++) {
                                if (count($_SESSION['vse_icons']) >= VSE_MAX_ICONS) {
                                    $capped = $total - $i;
                                    break;
                                }
                                $source = $sources[$i][0];
                                $id = $sources[$i][1];

                                if ($id !== '') {
                                    $finalId = vse_unique_id($id);
                                    $rawBytes = (int) $source->getAttribute('data-vse-raw');
                                    $symbolXml = vse_build_symbol($source, $finalId, $opt, $rawBytes > 0 ? $rawBytes : null);
                                    if (!vse_fits_in_session($finalId, $symbolXml)) {
                                        $bytesCapped = true;
                                        $capped = $total - $i;
                                        break;
                                    }
                                    vse_store_icon($finalId, $symbolXml);
                                    if ($finalId !== $id) {
                                        $renamed++;
                                    }
                                } else {
                                    $skipped++;
                                }
                            }
                            $notes = [];
                            if ($capped > 0) {
                                $notes[] = $bytesCapped
                                    ? 'Limite de ' . (VSE_MAX_SESSION_BYTES / 1048576) . ' MB por sessao atingido - ' . $capped . ' icone(s) deste arquivo nao foram importados.'
                                    : 'Limite de ' . VSE_MAX_ICONS . ' icones atingido - ' . $capped . ' icone(s) deste arquivo nao foram importados.';
                            }
                            if ($renamed > 0) {
                                $notes[] = $renamed . ' icone(s) com ID repetido foram mantidos lado a lado (renomeados com sufixo --2, --3...).';
                            }
                            if ($skipped > 0) {
                                $notes[] = $skipped . ' icone(s) ignorado(s) por ID invalido/ausente.';
                            }
                            if ($notes) {
                                $response['message'] = implode(' ', $notes);
                            }
                        } else {
                            $response['status'] = 'error';
                            $response['message'] = 'Nao foi possivel ler a estrutura do arquivo.';
                        }
                    }
                } elseif ($action === 'update') {
                    $id = trim((string)($req['id'] ?? ''));
                    $svg = trim((string)($req['svg'] ?? ''));

                    if ($id === '' || !isset($_SESSION['vse_icons'][$id])) {
                        $response['status'] = 'error';
                        $response['message'] = 'Icone nao encontrado.';
                    } elseif ($svg === '') {
                        $response['status'] = 'error';
                        $response['message'] = 'SVG e obrigatorio.';
                    } elseif (vse_has_doctype_or_entity($svg)) {
                        $response['status'] = 'error';
                        $response['message'] = 'DOCTYPE/ENTITY nao e permitido por seguranca.';
                    } else {
                        $dom = new DOMDocument();
                        libxml_use_internal_errors(true);
                        $wrapped = '<?xml version="1.0" encoding="UTF-8"?><wrapper>' . vse_strip_xml_prolog($svg) . '</wrapper>';

                        $loaded = $dom->loadXML($wrapped, LIBXML_NONET);
                        libxml_clear_errors();

                        if ($loaded) {
                            vse_clean_dom($dom);

                            $source = null;
                            $svgs = $dom->getElementsByTagName('svg');
                            $symbols = $dom->getElementsByTagName('symbol');

                            if ($svgs->length > 0) {
                                $source = $svgs->item(0);
                            } elseif ($symbols->length > 0) {
                                $source = $symbols->item(0);
                            }

                            if ($source) {
                                $symbolXml = vse_build_symbol($source, $id, $opt, strlen($svg));
                                if (!vse_fits_in_session($id, $symbolXml)) {
                                    $response['status'] = 'error';
                                    $response['message'] = 'Limite de ' . (VSE_MAX_SESSION_BYTES / 1048576) . ' MB de SVG por sessao atingido.';
                                } else {
                                    vse_store_icon($id, $symbolXml);
                                }
                            } else {
                                $response['status'] = 'error';
                                $response['message'] = 'Nenhuma tag valida encontrada.';
                            }
                        } else {
                            $response['status'] = 'error';
                            $response['message'] = 'Codigo SVG malformado.';
                        }
                    }
                } elseif ($action === 'resolve_duplicate') {
                    $keepId = trim((string)($req['id'] ?? ''));

                    if ($keepId === '' || !isset($_SESSION['vse_icons'][$keepId])) {
                        $response['status'] = 'error';
                        $response['message'] = 'Icone nao encontrado.';
                    } else {
                        $base = preg_replace('/--\d+$/', '', $keepId);
                        $keepSymbol = $_SESSION['vse_icons'][$keepId];
                        $keepMeta = isset($_SESSION['vse_meta'][$keepId]) ? $_SESSION['vse_meta'][$keepId] : null;

                        foreach (array_keys($_SESSION['vse_icons']) as $existingId) {
                            if ($existingId === $base || preg_match('/^' . preg_quote($base, '/') . '--\d+$/', $existingId)) {
                                unset($_SESSION['vse_icons'][$existingId]);
                            }
                        }

                        $_SESSION['vse_icons'][$base] = preg_replace('/id="[^"]*"/', 'id="' . $base . '"', $keepSymbol, 1);
                        if ($keepMeta !== null) {
                            $_SESSION['vse_meta'][$base] = $keepMeta;
                        }
                    }
                } elseif ($action === 'delete') {
                    $id = trim((string)($req['id'] ?? ''));
                    if (isset($_SESSION['vse_icons'][$id])) {
                        unset($_SESSION['vse_icons'][$id]);
                    }
                } elseif ($action === 'clear') {
                    $_SESSION['vse_icons'] = [];
                } elseif ($action === 'list') {
                }
            }

            if (isset($_SESSION['vse_icons'])) {
                $response['data'] = $_SESSION['vse_icons'];
            } else {
                $response['data'] = [];
            }

            $response['meta'] = array_intersect_key(isset($_SESSION['vse_meta']) ? $_SESSION['vse_meta'] : [], $response['data']);

            $optStats = vse_opt_stats();
            if ($optStats['before'] > 0) {
                $response['opt'] = $optStats;
            }

            ob_clean();
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($response, JSON_INVALID_UTF8_SUBSTITUTE);
            exit;
        }
    }
}
ob_end_clean();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> VARDI SVG Asset Pipeline & Sprite Builder</title>
    <style>
        :root {
            --vse-bg: #0b1220;
            --vse-bg-alt: #0f172a;
            --vse-surface: #151f32;
            --vse-surface-2: #1c2740;
            --vse-primary: #6366f1;
            --vse-primary-2: #3b82f6;
            --vse-primary-hover: #4f46e5;
            --vse-text: #f1f5f9;
            --vse-text-mut: #8b98ae;
            --vse-danger: #ef4444;
            --vse-success: #22c55e;
            --vse-radius: 10px;
            --vse-border: #263049;
            --vse-shadow: 0 8px 24px rgba(0,0,0,0.35);
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Inter', system-ui, -apple-system, "Segoe UI", sans-serif;
            background:
                radial-gradient(circle at 15% -10%, rgba(99,102,241,0.15), transparent 40%),
                radial-gradient(circle at 100% 0%, rgba(59,130,246,0.12), transparent 35%),
                var(--vse-bg);
            color: var(--vse-text);
            min-height: 100vh;
        }
        .vse-container { max-width: 1400px; margin: 0 auto; padding: 28px 24px 48px; }

        .vse-header {
            display: flex; justify-content: space-between; align-items: center;
            padding-bottom: 20px; margin-bottom: 28px;
            border-bottom: 1px solid var(--vse-border);
        }
        .vse-header h2 {
            margin: 0; font-size: 22px; font-weight: 800; letter-spacing: 0.3px;
            background: linear-gradient(90deg, #fff, #9db4ff);
            -webkit-background-clip: text; background-clip: text; color: transparent;
        }
        .vse-header .vse-sub { color: var(--vse-text-mut); font-size: 13px; margin-top: 4px; }

        .vse-grid { display: grid; grid-template-columns: 340px 1fr; gap: 24px; align-items: start; }

        .vse-panel {
            background: linear-gradient(180deg, var(--vse-surface), var(--vse-surface) 60%, var(--vse-bg-alt));
            padding: 20px; border-radius: var(--vse-radius); border: 1px solid var(--vse-border);
            box-shadow: var(--vse-shadow);
        }
        .vse-form { display: flex; flex-direction: column; gap: 14px; margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid var(--vse-border); }
        .vse-form:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
        .vse-form-title { font-size: 14px; font-weight: 700; color: var(--vse-text); margin: 0; display: flex; align-items: center; gap: 8px; }
        .vse-form-title .vse-step { display: inline-flex; align-items: center; justify-content: center; width: 20px; height: 20px; border-radius: 50%; background: var(--vse-primary); color: #fff; font-size: 11px; }

        .vse-form label { font-size: 12.5px; font-weight: 600; color: var(--vse-text-mut); display: block; margin-bottom: 6px; }
        .vse-input, .vse-textarea {
            width: 100%; background: var(--vse-bg-alt); color: var(--vse-text);
            border: 1px solid var(--vse-border); padding: 11px 12px; border-radius: 8px;
            font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 13px;
            transition: border-color 0.15s, box-shadow 0.15s;
        }
        .vse-textarea { min-height: 160px; resize: vertical; white-space: pre; }
        .vse-input:focus, .vse-textarea:focus { outline: none; border-color: var(--vse-primary-2); box-shadow: 0 0 0 3px rgba(59,130,246,0.18); }

        .vse-btn {
            background: linear-gradient(135deg, var(--vse-primary), var(--vse-primary-2));
            color: #fff; border: none; padding: 11px 16px; border-radius: 8px; cursor: pointer;
            font-weight: 600; font-size: 14px; transition: transform 0.12s, filter 0.15s;
        }
        .vse-btn:hover { filter: brightness(1.08); transform: translateY(-1px); }
        .vse-btn:active { transform: translateY(0); }
        .vse-btn:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
        .vse-btn-outline { background: transparent; border: 1px solid var(--vse-border); color: var(--vse-text); }
        .vse-btn-outline:hover { background: rgba(255,255,255,0.06); filter: none; }
        .vse-btn-sm { padding: 7px 12px; font-size: 12.5px; }

        .vse-dropzone {
            border: 1.5px dashed var(--vse-border); border-radius: 8px; padding: 22px 12px;
            text-align: center; color: var(--vse-text-mut); font-size: 12.5px; cursor: pointer;
            transition: border-color 0.15s, background 0.15s;
        }
        .vse-dropzone:hover, .vse-dropzone.is-drag { border-color: var(--vse-primary-2); background: rgba(59,130,246,0.06); color: var(--vse-text); }
        .vse-dropzone input { display: none; }
        .vse-dropzone .vse-file-list { margin-top: 8px; font-size: 11.5px; color: var(--vse-primary-2); word-break: break-all; }

        .vse-toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; gap: 12px; flex-wrap: wrap; }
        .vse-toolbar-title { font-size: 14px; font-weight: 700; color: var(--vse-text); }
        .vse-toolbar-title .vse-count { color: var(--vse-text-mut); font-weight: 500; font-size: 12.5px; margin-left: 6px; }
        .vse-search { flex: 1; min-width: 160px; max-width: 260px; }
        .vse-search input {
            width: 100%; background: var(--vse-bg-alt); border: 1px solid var(--vse-border); color: var(--vse-text);
            padding: 9px 12px; border-radius: 8px; font-size: 13px;
        }
        .vse-search input:focus { outline: none; border-color: var(--vse-primary-2); }

        .vse-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(128px, 1fr)); gap: 14px; align-items: start; }

        .vse-card {
            background: var(--vse-bg-alt); padding: 16px 12px; border-radius: var(--vse-radius);
            text-align: center; border: 2px solid var(--vse-border);
            display: flex; flex-direction: column; align-items: center; gap: 10px;
            position: relative; cursor: pointer; user-select: none;
            transition: border-color 0.15s, background 0.15s, transform 0.1s;
        }
        .vse-card:hover { border-color: #3a4a70; transform: translateY(-2px); }
        .vse-card.is-selected { border-color: var(--vse-primary-2); background: rgba(59,130,246,0.1); }
        .vse-card.is-hidden { display: none; }
        .vse-card.is-duplicate { border-color: #d97706; }
        .vse-card-dup {
            position: absolute; top: 8px; right: 8px; background: #d97706; color: #fff;
            font-size: 9.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px;
            padding: 2px 6px; border-radius: 4px;
        }
        .vse-btn-keep {
            background: #d97706; color: #fff; border: none; padding: 6px 10px;
            font-size: 11px; font-weight: 600; border-radius: 6px; cursor: pointer; width: 100%;
        }
        .vse-btn-keep:hover { filter: brightness(1.1); }

        .vse-card-cb {
            position: absolute; top: 10px; left: 10px; width: 16px; height: 16px;
            accent-color: var(--vse-primary-2); pointer-events: none;
        }
        .vse-card-icon { width: 40px; height: 40px; color: var(--vse-text); display: flex; align-items: center; justify-content: center; }
        .vse-card-icon svg { width: 100%; height: 100%; display: block; }
        .vse-card-tags { display: flex; gap: 4px; justify-content: center; flex-wrap: wrap; margin-top: 4px; }
        .vse-tag { font-size: 10px; padding: 1px 7px; border-radius: 999px; border: 1px solid var(--vse-border); color: var(--vse-text-mut); }
        .vse-tag.is-animated { color: #a5b4fc; border-color: rgba(99,102,241,0.55); }
        .vse-tag.is-warn { color: #fbbf24; border-color: rgba(251,191,36,0.55); }
        .vse-card-size { font-size: 10.5px; color: var(--vse-text-mut); text-align: center; margin-top: 2px; }
        .vse-report { margin: -6px 0 14px; font-size: 12.5px; color: var(--vse-text-mut); line-height: 1.5; }
        .vse-report strong { color: var(--vse-text); }
        .vse-card-id { font-size: 11px; color: var(--vse-text-mut); word-break: break-all; line-height: 1.3; }

        .vse-btn-del {
            background: transparent; color: var(--vse-danger); border: 1px solid transparent;
            padding: 5px 10px; font-size: 11.5px; border-radius: 6px; cursor: pointer; width: 100%;
            transition: background 0.15s, color 0.15s;
        }
        .vse-btn-del:hover { background: rgba(239,68,68,0.15); color: #fca5a5; }

        .vse-btn-code {
            background: transparent; color: var(--vse-text-mut); border: 1px solid var(--vse-border);
            padding: 5px 10px; font-size: 11px; border-radius: 6px; cursor: pointer; width: 100%;
        }
        .vse-btn-code:hover { color: var(--vse-text); border-color: #475569; }
        .vse-card-editor { width: 100%; display: flex; flex-direction: column; gap: 6px; }
        .vse-card-code-input {
            width: 100%; max-width: 100%; text-align: left; white-space: pre; word-break: break-all;
            background: #05080f; border: 1px solid var(--vse-border); border-radius: 6px;
            padding: 8px; font-size: 10px; color: var(--vse-text); font-family: 'JetBrains Mono', ui-monospace, monospace;
            min-height: 90px; resize: vertical;
        }
        .vse-card-code-input:focus { outline: none; border-color: var(--vse-primary-2); }
        .vse-btn-save-code {
            background: var(--vse-primary-2); color: #fff; border: none; padding: 6px 10px;
            font-size: 11px; font-weight: 600; border-radius: 6px; cursor: pointer;
        }
        .vse-btn-save-code:hover { filter: brightness(1.1); }

        .vse-empty { grid-column: 1/-1; color: var(--vse-text-mut); text-align: center; padding: 56px 0; font-size: 13.5px; }
        .vse-empty strong { color: var(--vse-text); display: block; margin-bottom: 6px; font-size: 15px; }

        .vse-toast-wrap { position: fixed; bottom: 20px; right: 20px; display: flex; flex-direction: column; gap: 10px; z-index: 999; }
        .vse-toast {
            background: var(--vse-surface-2); border: 1px solid var(--vse-border); color: var(--vse-text);
            padding: 12px 16px; border-radius: 8px; box-shadow: var(--vse-shadow);
            font-size: 13px; max-width: 320px; animation: vse-toast-in 0.2s ease-out;
        }
        .vse-toast.is-error { border-color: var(--vse-danger); }
        .vse-toast.is-success { border-color: var(--vse-success); }
        @keyframes vse-toast-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

        @media (max-width: 900px) {
            .vse-grid { grid-template-columns: 1fr; }
            .vse-header { flex-direction: column; gap: 12px; align-items: stretch; text-align: center; }
        }
    </style>
</head>
<body>

<input type="hidden" id="vse-csrf" value="<?php echo htmlspecialchars($_SESSION['vse_csrf'], ENT_QUOTES, 'UTF-8'); ?>">

<div class="vse-container">
    <header class="vse-header">
        <div>
            <h2>VARDI SVG Sprite Builder</h2>
            <div class="vse-sub">Combine e organize ícones SVG num único sprite otimizado</div>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
            <input type="text" id="vse-filename" class="vse-input" style="width: 150px;" value="sprites-final" placeholder="nome do arquivo" autocomplete="off">
            <label style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; color: var(--vse-text-mut); white-space: nowrap;">
                <input type="checkbox" id="vse-minify" checked style="accent-color: var(--vse-primary-2);"> Minificar
            </label>
            <label style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; color: var(--vse-text-mut); white-space: nowrap;" title="Limpa metadados, ids e defs sem uso, grupos redundantes e arredonda coordenadas. Vale para ícones importados depois de alterar.">
                <input type="checkbox" id="vse-optimize" checked style="accent-color: var(--vse-primary-2);"> Otimizar
            </label>
            <select id="vse-precision" class="vse-input" style="width: auto;" title="Casas decimais nas coordenadas (só na importação)">
                <option value="1">1 casa</option>
                <option value="2">2 casas</option>
                <option value="3" selected>3 casas</option>
                <option value="4">4 casas</option>
                <option value="-1">sem arredondar</option>
            </select>
            <button type="button" id="vse-btn-clear" class="vse-btn vse-btn-outline">Limpar Tudo</button>
            <button type="button" id="vse-btn-generate" class="vse-btn">Gerar SVG Final</button>
        </div>
    </header>

    <div class="vse-grid">
        <aside class="vse-panel">
            <form id="vse-form-import" class="vse-form">
                <h3 class="vse-form-title"><span class="vse-step">1</span> Mesclar Arquivos SVG</h3>
                <label for="vse-files">Selecione ou arraste um ou mais arquivos</label>
                <div id="vse-dropzone" class="vse-dropzone">
                    <div>📁 Arraste arquivos .svg (sprites ou ícones avulsos) ou clique para escolher</div>
                    <div id="vse-file-list" class="vse-file-list"></div>
                    <input type="file" id="vse-files" accept=".svg" multiple />
                </div>
                <button type="submit" class="vse-btn">Importar Ícones</button>
            </form>

            <form id="vse-form" class="vse-form">
                <h3 class="vse-form-title"><span class="vse-step">2</span> Adicionar Manualmente</h3>
                <div>
                    <label for="vse-id">ID do Ícone</label>
                    <input type="text" id="vse-id" class="vse-input" placeholder="ex: ic-home" autocomplete="off" />
                </div>
                <div>
                    <label for="vse-svg">Código Bruto (SVG / Symbol)</label>
                    <textarea id="vse-svg" class="vse-textarea" placeholder='&lt;svg viewBox=&quot;0 0 24 24&quot;&gt;...&lt;/svg&gt;'></textarea>
                </div>
                <button type="submit" id="vse-btn-add" class="vse-btn">Adicionar Ícone</button>
            </form>
        </aside>

        <main class="vse-panel">
            <div class="vse-toolbar">
                <div class="vse-toolbar-title">3. Selecione os ícones para o arquivo final<span id="vse-count" class="vse-count"></span></div>
                <div class="vse-search">
                    <input type="text" id="vse-filter" placeholder="Filtrar por ID..." autocomplete="off" />
                </div>
                <div style="display: flex; gap: 8px;">
                    <button type="button" id="vse-btn-sel-all" class="vse-btn vse-btn-outline vse-btn-sm">Todos</button>
                    <button type="button" id="vse-btn-sel-none" class="vse-btn vse-btn-outline vse-btn-sm">Nenhum</button>
                </div>
            </div>

            <div id="vse-report" class="vse-report"></div>

            <div id="vse-gallery" class="vse-gallery">
            </div>
        </main>
    </div>
</div>

<div id="vse-toast-wrap" class="vse-toast-wrap"></div>

<script>
const SpriteEditor = (() => {
    let currentIcons = {};
    let currentMeta = {};
    let selectedIds = new Set();
    let filterText = '';

    const DOM = {
        csrf: document.getElementById('vse-csrf').value,
        formAdd: document.getElementById('vse-form'),
        formImport: document.getElementById('vse-form-import'),
        inputId: document.getElementById('vse-id'),
        inputSvg: document.getElementById('vse-svg'),
        inputFiles: document.getElementById('vse-files'),
        dropzone: document.getElementById('vse-dropzone'),
        fileList: document.getElementById('vse-file-list'),
        gallery: document.getElementById('vse-gallery'),
        count: document.getElementById('vse-count'),
        report: document.getElementById('vse-report'),
        filter: document.getElementById('vse-filter'),
        toastWrap: document.getElementById('vse-toast-wrap'),
        btnGenerate: document.getElementById('vse-btn-generate'),
        filename: document.getElementById('vse-filename'),
        minify: document.getElementById('vse-minify'),
        optimize: document.getElementById('vse-optimize'),
        precision: document.getElementById('vse-precision'),
        btnClear: document.getElementById('vse-btn-clear'),
        btnSelAll: document.getElementById('vse-btn-sel-all'),
        btnSelNone: document.getElementById('vse-btn-sel-none')
    };

    const escapeHtml = (str) => String(str).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));

    const toast = (message, type = 'success') => {
        const el = document.createElement('div');
        el.className = 'vse-toast is-' + type;
        el.textContent = message;
        DOM.toastWrap.appendChild(el);
        setTimeout(() => el.remove(), 4000);
    };

    const fmtBytes = (n) => n >= 1024 ? (n / 1024).toFixed(2) + ' KB' : n + ' B';
    const pct = (before, after) => before > 0 ? ((before - after) / before * 100).toFixed(1) : '0.0';
    const byteLen = (str) => new TextEncoder().encode(str || '').length;

    const optNote = (opt) => {
        if (!opt || !opt.before) return '';
        let note = '';
        const saved = opt.before - opt.after;
        if (saved > 0) note += ' Otimização: −' + fmtBytes(saved) + ' (' + pct(opt.before, opt.after) + '%).';
        if (opt.fallbacks > 0) note += ' ' + opt.fallbacks + ' ícone(s) mantido(s) em modo seguro (sem otimizar).';
        return note;
    };

    const isAnimated = (id) => {
        const m = currentMeta[id];
        if (m && typeof m.animated === 'boolean') return m.animated;
        return /<(animate|animatetransform|animatemotion|animatecolor|set|discard)[\s/>]/i.test(currentIcons[id] || '');
    };

    const selectionStats = () => {
        const st = { count: 0, animated: 0, statics: 0, raw: 0, after: 0, safe: 0 };
        Object.keys(currentIcons).forEach(id => {
            if (!selectedIds.has(id)) return;
            const size = byteLen(currentIcons[id]);
            const m = currentMeta[id];
            st.count++;
            if (isAnimated(id)) st.animated++; else st.statics++;
            st.after += size;
            st.raw += m ? m.raw : size;
            if (m && m.status === 'fallback') st.safe++;
        });
        return st;
    };

    const updateReport = () => {
        if (Object.keys(currentIcons).length === 0) {
            DOM.report.innerHTML = '';
            return;
        }
        const st = selectionStats();
        if (st.count === 0) {
            DOM.report.textContent = 'Nenhum ícone selecionado.';
            return;
        }
        const saved = st.raw - st.after;
        DOM.report.innerHTML = '<strong>Sprite final</strong> · ' + st.count + ' ícone(s): ' + st.animated + ' animado(s), ' + st.statics + ' estático(s)'
            + ' · Antes ' + fmtBytes(st.raw) + ' → Depois ' + fmtBytes(st.after)
            + ' · ' + (saved >= 0 ? 'Economia ' : 'Aumento ') + fmtBytes(Math.abs(saved)) + ' (' + pct(st.raw, st.after) + '%)'
            + (st.safe > 0 ? ' · ' + st.safe + ' em modo seguro' : '');
    };

    const request = async (action, payload = {}) => {
        payload.action = action;
        payload.csrf = DOM.csrf;
        payload.optimize = DOM.optimize.checked;
        payload.precision = parseInt(DOM.precision.value, 10);
        try {
            const res = await fetch(window.location.pathname, {
                method: 'POST',
                body: JSON.stringify(payload)
            });
            const text = await res.text();
            try {
                const parsed = JSON.parse(text);
                if (parsed && parsed.meta) currentMeta = parsed.meta;
                return parsed;
            } catch (jsonErr) {
                console.error('Falha no JSON:', text);
                return { status: 'error', message: 'Servidor não retornou JSON válido.' };
            }
        } catch (err) {
            console.error('Falha de rede:', err);
            return { status: 'error', message: 'Falha de rede HTTP.' };
        }
    };

    const ensureXmlns = (svgTag) => {
        if (/xmlns\s*=/.test(svgTag)) return svgTag;
        return svgTag.replace(/^<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
    };

    const toPreviewMarkup = (rawSymbol) => {
        return ensureXmlns(
            rawSymbol.replace(/<symbol/i, '<svg').replace(/<\/symbol>/i, '</svg>')
        ).replace(/currentColor/g, '#e5e9f2');
    };

    const render = (data) => {
        const keys = Object.keys(data);
        for (let i = 0; i < keys.length; i++) {
            const k = keys[i];
            if (currentIcons[k] === undefined) {
                selectedIds.add(k);
            }
        }

        currentIcons = data;
        const animatedTotal = keys.filter(isAnimated).length;
        DOM.count.textContent = keys.length
            ? `(${keys.length} ícone${keys.length === 1 ? '' : 's'}: ${keys.length - animatedTotal} estático${keys.length - animatedTotal === 1 ? '' : 's'}, ${animatedTotal} animado${animatedTotal === 1 ? '' : 's'})`
            : '';

        const baseIdOf = (id) => id.replace(/--\d+$/, '');
        const groups = new Map();
        for (let i = 0; i < keys.length; i++) {
            const base = baseIdOf(keys[i]);
            if (!groups.has(base)) groups.set(base, []);
            groups.get(base).push(keys[i]);
        }
        const orderedKeys = [];
        groups.forEach(group => {
            group.sort();
            orderedKeys.push(...group);
        });

        let cardsHTML = '';
        const needle = filterText.trim().toLowerCase();

        for (let i = 0; i < orderedKeys.length; i++) {
            const id = orderedKeys[i];
            const isSel = selectedIds.has(id);
            const matches = !needle || id.toLowerCase().includes(needle);
            const isDuplicate = groups.get(baseIdOf(id)).length > 1;

            let rawSymbol = currentIcons[id];
            const meta = currentMeta[id];
            const anim = isAnimated(id);
            const sizeLine = meta && meta.raw > 0
                ? fmtBytes(meta.raw) + ' → ' + fmtBytes(meta.size) + ' (' + (meta.size <= meta.raw ? '−' : '+') + (Math.abs(meta.size - meta.raw) / meta.raw * 100).toFixed(1) + '%)'
                : '';

            cardsHTML += `
                <div class="vse-card ${isSel ? 'is-selected' : ''} ${matches ? '' : 'is-hidden'} ${isDuplicate ? 'is-duplicate' : ''}" data-id="${escapeHtml(id)}">
                    <input type="checkbox" class="vse-card-cb" ${isSel ? 'checked' : ''} tabindex="-1">
                    ${isDuplicate ? '<div class="vse-card-dup">duplicata</div>' : ''}
                    <div class="vse-card-icon">
                        ${toPreviewMarkup(rawSymbol)}
                    </div>
                    <div class="vse-card-id">${escapeHtml(id)}</div>
                    <div class="vse-card-tags">
                        <span class="vse-tag ${anim ? 'is-animated' : 'is-static'}">${anim ? '◉ animado' : '☷ estático'}</span>
                        ${meta && meta.status === 'fallback' ? '<span class="vse-tag is-warn" title="A otimização foi descartada porque quebraria referências, animação ou geometria.">modo seguro</span>' : ''}
                    </div>
                    ${sizeLine ? `<div class="vse-card-size">${sizeLine}</div>` : ''}
                    <button type="button" class="vse-btn-code" data-id="${escapeHtml(id)}">Código</button>
                    <div class="vse-card-editor" data-id="${escapeHtml(id)}" hidden>
                        <textarea class="vse-card-code-input" data-id="${escapeHtml(id)}" spellcheck="false">${escapeHtml(rawSymbol)}</textarea>
                        <button type="button" class="vse-btn-save-code" data-id="${escapeHtml(id)}">Salvar edição</button>
                    </div>
                    ${isDuplicate ? `<button type="button" class="vse-btn-keep" data-id="${escapeHtml(id)}">Manter só este</button>` : ''}
                    <button type="button" class="vse-btn-del" data-id="${escapeHtml(id)}">Apagar</button>
                </div>
            `;
        }

        if (keys.length === 0) {
            DOM.gallery.innerHTML = '<div class="vse-empty"><strong>Nenhum ícone carregado</strong>Faça upload de arquivos ou adicione manualmente.</div>';
        } else {
            DOM.gallery.innerHTML = cardsHTML;
        }
        updateReport();

        document.querySelectorAll('.vse-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (e.target.closest('.vse-btn-del, .vse-btn-code, .vse-card-editor, .vse-btn-keep')) return;

                const id = card.getAttribute('data-id');
                if (selectedIds.has(id)) {
                    selectedIds.delete(id);
                    card.classList.remove('is-selected');
                    card.querySelector('.vse-card-cb').checked = false;
                } else {
                    selectedIds.add(id);
                    card.classList.add('is-selected');
                    card.querySelector('.vse-card-cb').checked = true;
                }
                updateReport();
            });
        });

        document.querySelectorAll('.vse-btn-keep').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                if (!confirm('Manter só este ícone e apagar as outras versões duplicadas deste ID?')) return;

                const targetId = e.target.getAttribute('data-id');
                const res = await request('resolve_duplicate', { id: targetId });
                if (res.status === 'success') {
                    selectedIds.delete(targetId);
                    render(res.data);
                    toast('Duplicata resolvida.');
                } else {
                    toast(res.message || 'Erro ao resolver duplicata.', 'error');
                }
            });
        });

        document.querySelectorAll('.vse-btn-code').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const targetId = e.target.getAttribute('data-id');
                const editor = document.querySelector('.vse-card-editor[data-id="' + CSS.escape(targetId) + '"]');
                if (editor) editor.hidden = !editor.hidden;
            });
        });

        document.querySelectorAll('.vse-btn-save-code').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const targetId = e.target.getAttribute('data-id');
                const textarea = document.querySelector('.vse-card-code-input[data-id="' + CSS.escape(targetId) + '"]');
                if (!textarea) return;

                btn.disabled = true;
                btn.textContent = 'Salvando...';
                const res = await request('update', { id: targetId, svg: textarea.value });
                if (res.status === 'success') {
                    render(res.data);
                    toast('Ícone atualizado.' + optNote(res.opt));
                } else {
                    toast(res.message || 'Erro ao salvar edição.', 'error');
                    btn.disabled = false;
                    btn.textContent = 'Salvar edição';
                }
            });
        });

        document.querySelectorAll('.vse-btn-del').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                if (!confirm('Deseja realmente apagar este ícone da área de trabalho?')) return;

                const targetId = e.target.getAttribute('data-id');
                const res = await request('delete', { id: targetId });
                if (res.status === 'success') {
                    selectedIds.delete(targetId);
                    render(res.data);
                    toast('Ícone removido.');
                } else {
                    toast(res.message || 'Erro ao apagar.', 'error');
                }
            });
        });
    };

    const handleFiles = async (files) => {
        if (!files || files.length === 0) return;

        DOM.fileList.textContent = Array.from(files).map(f => f.name).join(', ');
        const btnSubmit = DOM.formImport.querySelector('button');
        btnSubmit.disabled = true;
        btnSubmit.innerText = 'Importando...';

        let importedCount = 0;
        let optBefore = 0, optAfter = 0, optFallbacks = 0;
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const text = await file.text();
            const res = await request('import', { svg: text, name: file.name });
            if (res.status === 'success') {
                currentIcons = res.data;
                importedCount++;
                if (res.opt) { optBefore += res.opt.before; optAfter += res.opt.after; optFallbacks += res.opt.fallbacks || 0; }
                if (res.message) toast(res.message, 'error');
            } else {
                toast('Erro no arquivo ' + file.name + ': ' + res.message, 'error');
            }
        }

        render(currentIcons);
        if (importedCount > 0) toast('Importação concluída.' + optNote({ before: optBefore, after: optAfter, fallbacks: optFallbacks }));
        DOM.inputFiles.value = '';
        DOM.fileList.textContent = '';
        btnSubmit.disabled = false;
        btnSubmit.innerText = 'Importar Ícones';
    };

    const init = () => {
        DOM.formImport.addEventListener('submit', (e) => {
            e.preventDefault();
            handleFiles(DOM.inputFiles.files);
        });

        DOM.inputFiles.addEventListener('change', () => {
            DOM.fileList.textContent = Array.from(DOM.inputFiles.files).map(f => f.name).join(', ');
        });

        DOM.dropzone.addEventListener('click', () => DOM.inputFiles.click());
        ['dragenter', 'dragover'].forEach(evt => {
            DOM.dropzone.addEventListener(evt, (e) => {
                e.preventDefault();
                DOM.dropzone.classList.add('is-drag');
            });
        });
        ['dragleave', 'drop'].forEach(evt => {
            DOM.dropzone.addEventListener(evt, (e) => {
                e.preventDefault();
                DOM.dropzone.classList.remove('is-drag');
            });
        });
        DOM.dropzone.addEventListener('drop', (e) => {
            handleFiles(e.dataTransfer.files);
        });

        DOM.formAdd.addEventListener('submit', async (e) => {
            e.preventDefault();
            const id = DOM.inputId.value.trim();
            const svg = DOM.inputSvg.value.trim();

            if (id !== '' && svg !== '') {
                const res = await request('add', { id: id, svg: svg });
                if (res.status === 'success') {
                    DOM.inputId.value = '';
                    DOM.inputSvg.value = '';
                    render(res.data);
                    toast('Ícone adicionado.' + optNote(res.opt));
                } else {
                    toast(res.message || 'Erro ao adicionar.', 'error');
                }
            }
        });

        DOM.filter.addEventListener('input', () => {
            filterText = DOM.filter.value;
            render(currentIcons);
        });

        DOM.btnSelAll.addEventListener('click', () => {
            const keys = Object.keys(currentIcons);
            for (let i = 0; i < keys.length; i++) selectedIds.add(keys[i]);
            render(currentIcons);
        });

        DOM.btnSelNone.addEventListener('click', () => {
            selectedIds.clear();
            render(currentIcons);
        });

        DOM.btnClear.addEventListener('click', async () => {
            if (confirm('Limpar todos os ícones da sessão e recomeçar?')) {
                const res = await request('clear');
                if (res.status === 'success') {
                    selectedIds.clear();
                    render(res.data);
                    toast('Área de trabalho limpa.');
                }
            }
        });

        DOM.btnGenerate.addEventListener('click', () => {
            if (selectedIds.size === 0) {
                toast('Selecione pelo menos um ícone na galeria para gerar o arquivo.', 'error');
                return;
            }

            const baseIdOf = (id) => id.replace(/--\d+$/, '');
            const usedBaseIds = new Set();
            let renamedCount = 0;

            let symbols = '';
            const keys = Object.keys(currentIcons);
            for (let i = 0; i < keys.length; i++) {
                const id = keys[i];
                if (!selectedIds.has(id)) continue;

                const base = baseIdOf(id);
                let outId = id;
                if (!usedBaseIds.has(base)) {
                    outId = base;
                    usedBaseIds.add(base);
                }

                let markup = currentIcons[id];
                if (outId !== id) {
                    markup = markup.replace(/id="[^"]*"/, 'id="' + outId + '"');
                    renamedCount++;
                }
                symbols += markup + '\n';
            }

            const minify = DOM.minify && DOM.minify.checked;
            const xlinkNs = symbols.indexOf('xlink:') !== -1 ? ' xmlns:xlink="http://www.w3.org/1999/xlink"' : '';
            const finalSvg = `<svg xmlns="http://www.w3.org/2000/svg"${xlinkNs} style="display:none">\n${symbols}</svg>`;

            const outputSvg = minify
                ? finalSvg.replace(/>\s+</g, '><').replace(/[ \t]{2,}/g, ' ').trim()
                : finalSvg;

            const blob = new Blob([outputSvg], { type: 'image/svg+xml' });
            const url = URL.createObjectURL(blob);

            let name = (DOM.filename.value || 'sprites-final').trim().replace(/\.svg$/i, '');
            name = name.replace(/[\\/:*?"<>|]/g, '-') || 'sprites-final';

            const a = document.createElement('a');
            a.href = url;
            a.download = name + '.svg';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            const st = selectionStats();
            toast(selectedIds.size + ' ícone(s) exportado(s)' + (renamedCount > 0 ? ' (' + renamedCount + ' com nome original restaurado)' : '') + '.'
                + (st.raw > st.after ? ' ' + fmtBytes(st.raw) + ' → ' + fmtBytes(st.after) + ' (−' + pct(st.raw, st.after) + '%).' : ''));
        });

        request('list').then(res => {
            if (res.status === 'success') {
                render(res.data);
            } else {
                toast(res.message || 'Erro ao carregar ícones.', 'error');
            }
        });
    };

    return { init };
})();

document.addEventListener('DOMContentLoaded', SpriteEditor.init);
</script>
</body>
</html>
